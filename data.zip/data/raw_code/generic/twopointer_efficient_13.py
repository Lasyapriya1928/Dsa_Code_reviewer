def reverse_list(chars):
    left = 0
    right = len(chars) - 1

    while left < right:
        chars[left], chars[right] = chars[right], chars[left]
        left += 1
        right -= 1

    return chars


print(reverse_list(["h","e","l","l","o"]))